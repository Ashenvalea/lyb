let currentPage = 1;
let currentUser = null;
let userProfile = null;
let currentView = 'main';
const API_BASE = 'http://182.92.159.55:3000/api';
const authSection = document.getElementById('auth-section');
const mainSection = document.getElementById('main-section');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const messageForm = document.getElementById('message-form');
const messagesContainer = document.getElementById('messages-container');
const paginationContainer = document.getElementById('pagination');
const currentUsernameSpan = document.getElementById('current-username');
const messageContent = document.getElementById('message-content');
const charCount = document.getElementById('char-count');

document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
        currentUser = JSON.parse(user);
        showMainSection();
        loadMessages();
        
        const avatarElement = document.getElementById('current-user-avatar');
        if (avatarElement && currentUser.avatar_url) {
            updateAvatarDisplay(currentUser.avatar_url);
        }
    }

    setupEventListeners();
    
    const avatarFileInput = document.getElementById('avatar-file');
    if (avatarFileInput) {
        avatarFileInput.addEventListener('change', handleAvatarUpload);
    }
});

function setupEventListeners() {
    loginForm.addEventListener('submit', handleLogin);
    registerForm.addEventListener('submit', handleRegister);
    messageForm.addEventListener('submit', handleMessageSubmit);
    messageContent.addEventListener('input', updateCharCount);
}

function showLogin() {
    document.querySelector('.tab-btn.active').classList.remove('active');
    document.querySelector('.tab-btn').classList.add('active');
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
}

function showRegister() {
    document.querySelector('.tab-btn.active').classList.remove('active');
    document.querySelectorAll('.tab-btn')[1].classList.add('active');
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
}

function showMainSection() {
    authSection.style.display = 'none';
    mainSection.style.display = 'block';
    currentUsernameSpan.textContent = currentUser.username;
}

function showAuthSection() {
    authSection.style.display = 'flex';
    mainSection.style.display = 'none';
}

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    
    if (!username || !password) {
        showToast('请填写用户名和密码', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            
            showToast('登录成功！', 'success');
            showWelcomeModal();
            showMainSection();
            loadMessages();
            
            loginForm.reset();
        } else {
            if (data.errorType === 'USER_NOT_FOUND') {
                showRegisterPrompt(username);
            } else if (data.errorType === 'INVALID_PASSWORD') {
                showPasswordErrorPrompt(data.username);
            } else {
                showToast(data.error || '登录失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('登录错误:', error);
    }
}

function showRegisterPrompt(username) {
    const modal = document.createElement('div');
    modal.className = 'register-prompt-modal';
    modal.innerHTML = `
        <div class="register-prompt-content">
            <h3>用户不存在</h3>
            <p>用户名 "${escapeHtml(username)}" 尚未注册</p>
            <p>是否要使用此用户名进行注册？</p>
            <div class="register-prompt-actions">
                <button class="btn btn-primary" onclick="goToRegister('${escapeHtml(username)}')">去注册</button>
                <button class="btn btn-secondary" onclick="closeRegisterPrompt()">取消</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function goToRegister(username) {
    closeRegisterPrompt();
    showRegister();
    document.getElementById('register-username').value = username;
    document.getElementById('register-username').focus();
}

function closeRegisterPrompt() {
    const modal = document.querySelector('.register-prompt-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function showPasswordErrorPrompt(username) {
    const modal = document.createElement('div');
    modal.className = 'password-error-modal';
    modal.innerHTML = `
        <div class="password-error-content">
            <div class="password-error-icon">⚠️</div>
            <h3>密码错误</h3>
            <p>用户名 "<strong>${escapeHtml(username)}</strong>" 的密码输入有误</p>
            <p>请重新输入正确的密码，或联系管理员重置密码</p>
            <div class="password-error-actions">
                <button class="btn btn-primary" onclick="closePasswordErrorPrompt()">重新输入</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
    
    setTimeout(() => {
        document.getElementById('login-password').focus();
        document.getElementById('login-password').select();
    }, 300);
}

function closePasswordErrorPrompt() {
    const modal = document.querySelector('.password-error-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    if (!username || !password || !confirmPassword) {
        showToast('请填写所有字段', 'error');
        return;
    }

    if (password !== confirmPassword) {
        showToast('两次输入的密码不一致', 'error');
        return;
    }

    if (password.length < 6) {
        showToast('密码长度至少6位', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            
            showToast('注册成功！', 'success');
            showWelcomeModal();
            showMainSection();
            loadMessages();
            
            registerForm.reset();
        } else {
            if (data.errorType === 'USER_EXISTS') {
                showUserExistsPrompt(data.existingUsername);
            } else {
                showToast(data.error || '注册失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('注册错误:', error);
    }
}

function showUserExistsPrompt(username) {
    const modal = document.createElement('div');
    modal.className = 'user-exists-modal';
    modal.innerHTML = `
        <div class="user-exists-content">
            <div class="user-exists-icon">👤</div>
            <h3>用户名已被占用</h3>
            <p>用户名 "<strong>${escapeHtml(username)}</strong>" 已经被其他用户注册</p>
            <p>请尝试使用其他用户名进行注册</p>
            <div class="user-exists-actions">
                <button class="btn btn-primary" onclick="closeUserExistsPrompt()">重新输入</button>
                <button class="btn btn-secondary" onclick="goToLoginFromExists('${escapeHtml(username)}')">已有账户，去登录</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
    
    setTimeout(() => {
        document.getElementById('register-username').focus();
        document.getElementById('register-username').select();
    }, 300);
}

function closeUserExistsPrompt() {
    const modal = document.querySelector('.user-exists-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
}

function goToLoginFromExists(username) {
    closeUserExistsPrompt();
    showLogin();
    document.getElementById('login-username').value = username;
    document.getElementById('login-password').focus();
}

async function handleMessageSubmit(e) {
    e.preventDefault();
    
    const content = messageContent.value.trim();
    
    if (!content) {
        showToast('请输入留言内容', 'error');
        return;
    }

    if (content.length > 500) {
        showToast('留言内容不能超过500字符', 'error');
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/messages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ content })
        });

        const data = await response.json();

        if (response.ok) {
            showToast('留言发布成功！', 'success');
            messageContent.value = '';
            updateCharCount();
            loadMessages(1);
            currentPage = 1;
        } else {
            if (response.status === 401 || response.status === 403) {
                handleTokenExpired();
            } else {
                showToast(data.error || '发布留言失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('发布留言错误:', error);
    }
}

async function loadMessages(page = 1) {
    try {
        const response = await fetch(`${API_BASE}/messages?page=${page}&limit=10`);
        const data = await response.json();

        if (response.ok) {
            renderMessages(data.messages);
            renderPagination(data.pagination);
            currentPage = page;
        } else {
            showToast('获取留言失败', 'error');
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('获取留言错误:', error);
    }
}

function renderMessages(messages) {
    if (!messages || messages.length === 0) {
        messagesContainer.innerHTML = '<div class="no-messages">暂无留言</div>';
        return;
    }

    messagesContainer.innerHTML = messages.map(message => {
        const messageTime = formatDate(message.created_at);
        const isOwner = currentUser && currentUser.id === message.user_id;
        
        return `
            <div class="message-card" data-message-id="${message.id}">
                <div class="message-header">
                    <div class="message-user">
                        <div class="user-avatar clickable-avatar" onclick="showUserProfile(${message.user_id})" data-user-id="${message.user_id}" style="${message.user_avatar ? `background-image: url(${message.user_avatar}); background-size: cover; background-position: center;` : ''}">${message.user_avatar ? '' : '👤'}</div>
                        <span class="username clickable-username" onclick="showUserProfile(${message.user_id})">${escapeHtml(message.username)}</span>
                    </div>
                    <div class="message-meta">
                        <span class="message-time">${messageTime}</span>
                        ${isOwner ? `<button class="btn-delete" onclick="deleteMessage(${message.id})" title="删除留言">🗑️</button>` : ''}
                    </div>
                </div>
                <div class="message-content">
                    ${escapeHtml(message.content)}
                </div>
                <div class="message-actions">
                    <button class="action-btn like-btn" onclick="toggleLike(${message.id})" data-message-id="${message.id}">
                        <span class="like-icon">👍</span>
                        <span class="like-count">${message.like_count || 0}</span>
                    </button>
                    <button class="action-btn reply-btn" onclick="toggleReplyBox(${message.id})">
                        <span class="reply-icon">💬</span>
                        <span class="reply-count">${message.reply_count || 0}</span>
                    </button>
                    <button class="action-btn view-replies-btn" onclick="toggleReplies(${message.id})" style="display: ${(message.reply_count || 0) > 0 ? 'inline-flex' : 'none'}">
                        查看回复
                    </button>
                </div>
                <div class="reply-box" id="reply-box-${message.id}" style="display: none;">
                    <textarea placeholder="写下你的回复..." maxlength="300" class="reply-input" id="reply-input-${message.id}"></textarea>
                    <div class="reply-actions">
                        <span class="char-count-small"><span id="reply-char-count-${message.id}">0</span>/300</span>
                        <button class="btn btn-small" onclick="submitReply(${message.id})">发送回复</button>
                        <button class="btn btn-small btn-cancel" onclick="toggleReplyBox(${message.id})">取消</button>
                    </div>
                </div>
                <div class="replies-container" id="replies-${message.id}" style="display: none;">
                    <div class="replies-loading">加载回复中...</div>
                </div>
            </div>
        `;
    }).join('');

    updateLikeStatuses(messages);
}

async function updateLikeStatuses(messages) {
    if (!currentUser) return;

    for (const message of messages) {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`${API_BASE}/messages/${message.id}/like-status`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                const likeBtn = document.querySelector(`[data-message-id="${message.id}"].like-btn`);
                if (likeBtn && data.liked) {
                    likeBtn.classList.add('liked');
                }
            }
        } catch (error) {
            console.error('获取点赞状态失败:', error);
        }
    }
}

async function toggleLike(messageId) {
    if (!currentUser) {
        showToast('请先登录', 'error');
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/messages/${messageId}/like`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            const likeBtn = document.querySelector(`[data-message-id="${messageId}"].like-btn`);
            const likeCount = likeBtn.querySelector('.like-count');
            
            if (data.liked) {
                likeBtn.classList.add('liked');
                likeCount.textContent = parseInt(likeCount.textContent) + 1;
                showToast('点赞成功', 'success');
            } else {
                likeBtn.classList.remove('liked');
                likeCount.textContent = Math.max(0, parseInt(likeCount.textContent) - 1);
                showToast('取消点赞', 'info');
            }
        } else {
            if (response.status === 401 || response.status === 403) {
                handleTokenExpired();
            } else {
                showToast(data.error || '操作失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('点赞操作错误:', error);
    }
}

function toggleReplyBox(messageId) {
    const replyBox = document.getElementById(`reply-box-${messageId}`);
    const replyInput = document.getElementById(`reply-input-${messageId}`);
    
    if (replyBox.style.display === 'none') {
        replyBox.style.display = 'block';
        replyInput.focus();
        
        replyInput.addEventListener('input', () => updateReplyCharCount(messageId));
    } else {
        replyBox.style.display = 'none';
        replyInput.value = '';
        updateReplyCharCount(messageId);
    }
}

function updateReplyCharCount(messageId) {
    const input = document.getElementById(`reply-input-${messageId}`);
    const counter = document.getElementById(`reply-char-count-${messageId}`);
    
    if (input && counter) {
        const count = input.value.length;
        counter.textContent = count;
        
        if (count > 300) {
            counter.style.color = '#e53e3e';
        } else if (count > 250) {
            counter.style.color = '#ed8936';
        } else {
            counter.style.color = '#718096';
        }
    }
}

async function submitReply(messageId) {
    const replyInput = document.getElementById(`reply-input-${messageId}`);
    const content = replyInput.value.trim();

    if (!content) {
        showToast('请输入回复内容', 'error');
        return;
    }

    if (content.length > 300) {
        showToast('回复内容不能超过300字符', 'error');
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/messages/${messageId}/reply`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ content })
        });

        const data = await response.json();

        if (response.ok) {
            showToast('回复发送成功', 'success');
            replyInput.value = '';
            updateReplyCharCount(messageId);
            toggleReplyBox(messageId);
            
            const replyCountSpan = document.querySelector(`[onclick="toggleReplyBox(${messageId})"] .reply-count`);
            const viewRepliesBtn = document.querySelector(`[onclick="toggleReplies(${messageId})"]`);
            
            if (replyCountSpan) {
                const newCount = parseInt(replyCountSpan.textContent) + 1;
                replyCountSpan.textContent = newCount;
                
                if (viewRepliesBtn && newCount > 0) {
                    viewRepliesBtn.style.display = 'inline-flex';
                }
            }
            
            const repliesContainer = document.getElementById(`replies-${messageId}`);
            if (repliesContainer && repliesContainer.style.display !== 'none') {
                loadReplies(messageId);
            }
        } else {
            if (response.status === 401 || response.status === 403) {
                handleTokenExpired();
            } else {
                showToast(data.error || '回复发送失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('回复发送错误:', error);
    }
}

async function toggleReplies(messageId) {
    const repliesContainer = document.getElementById(`replies-${messageId}`);
    
    if (repliesContainer.style.display === 'none') {
        repliesContainer.style.display = 'block';
        await loadReplies(messageId);
    } else {
        repliesContainer.style.display = 'none';
    }
}

async function loadReplies(messageId, page = 1) {
    const repliesContainer = document.getElementById(`replies-${messageId}`);
    
    try {
        const response = await fetch(`${API_BASE}/messages/${messageId}/replies?page=${page}&limit=5`);
        const data = await response.json();

        if (response.ok) {
            if (data.replies && data.replies.length > 0) {
                repliesContainer.innerHTML = `
                    <div class="replies-header">
                        <h4>回复 (${data.pagination.total})</h4>
                    </div>
                    <div class="replies-list">
                        ${data.replies.map(reply => {
                            const isOwner = currentUser && currentUser.id === reply.user_id;
                            return `
                                <div class="reply-item" data-reply-id="${reply.id}">
                                    <div class="reply-header">
                                        <div class="reply-user">
                                            <div class="user-avatar-small clickable-avatar" onclick="showUserProfile(${reply.user_id})" data-user-id="${reply.user_id}" style="${reply.user_avatar ? `background-image: url(${reply.user_avatar}); background-size: cover; background-position: center;` : ''}">${reply.user_avatar ? '' : '👤'}</div>
                                            <span class="reply-username clickable-username" onclick="showUserProfile(${reply.user_id})">${escapeHtml(reply.username)}</span>
                                        </div>
                                        <div class="reply-meta">
                                            <span class="reply-time">${formatDate(reply.created_at)}</span>
                                            ${isOwner ? `<button class="btn-delete-small" onclick="deleteReply(${reply.id}, ${messageId})" title="删除回复">🗑️</button>` : ''}
                                        </div>
                                    </div>
                                    <div class="reply-content">
                                        ${escapeHtml(reply.content)}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    ${data.pagination.totalPages > 1 ? renderRepliesPagination(messageId, data.pagination) : ''}
                `;
            } else {
                repliesContainer.innerHTML = '<div class="no-replies">暂无回复</div>';
            }
        } else {
            repliesContainer.innerHTML = '<div class="replies-error">加载回复失败</div>';
        }
    } catch (error) {
        console.error('加载回复错误:', error);
        repliesContainer.innerHTML = '<div class="replies-error">网络错误</div>';
    }
}

function renderRepliesPagination(messageId, pagination) {
    const { page, totalPages } = pagination;
    let paginationHtml = '<div class="replies-pagination">';
    
    if (page > 1) {
        paginationHtml += `<button class="page-btn" onclick="loadReplies(${messageId}, ${page - 1})">上一页</button>`;
    }
    
    paginationHtml += `<span class="page-info">${page} / ${totalPages}</span>`;
    
    if (page < totalPages) {
        paginationHtml += `<button class="page-btn" onclick="loadReplies(${messageId}, ${page + 1})">下一页</button>`;
    }
    
    paginationHtml += '</div>';
    return paginationHtml;
}

async function deleteReply(replyId, messageId) {
    if (!confirm('确定要删除这条回复吗？')) {
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/replies/${replyId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            showToast('回复删除成功', 'success');
            
            const replyCountSpan = document.querySelector(`[onclick="toggleReplyBox(${messageId})"] .reply-count`);
            if (replyCountSpan) {
                const newCount = Math.max(0, parseInt(replyCountSpan.textContent) - 1);
                replyCountSpan.textContent = newCount;
                
                const viewRepliesBtn = document.querySelector(`[onclick="toggleReplies(${messageId})"]`);
                if (viewRepliesBtn && newCount === 0) {
                    viewRepliesBtn.style.display = 'none';
                    document.getElementById(`replies-${messageId}`).style.display = 'none';
                }
            }
            
            if (document.getElementById(`replies-${messageId}`).style.display !== 'none') {
                loadReplies(messageId);
            }
        } else {
            if (response.status === 401 || response.status === 403) {
                if (data.error === '只能删除自己的回复') {
                    showToast(data.error, 'error');
                } else {
                    handleTokenExpired();
                }
            } else {
                showToast(data.error || '删除回复失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('删除回复错误:', error);
    }
}

function renderPagination(pagination) {
    if (pagination.totalPages <= 1) {
        paginationContainer.innerHTML = '';
        return;
    }

    let paginationHTML = '';

    if (pagination.page > 1) {
        paginationHTML += `<button onclick="loadMessages(${pagination.page - 1})">上一页</button>`;
    }

    for (let i = 1; i <= pagination.totalPages; i++) {
        if (i === pagination.page) {
            paginationHTML += `<button class="active">${i}</button>`;
        } else {
            paginationHTML += `<button onclick="loadMessages(${i})">${i}</button>`;
        }
    }

    if (pagination.page < pagination.totalPages) {
        paginationHTML += `<button onclick="loadMessages(${pagination.page + 1})">下一页</button>`;
    }

    paginationContainer.innerHTML = paginationHTML;
}

async function deleteMessage(messageId) {
    if (!confirm('确定要删除这条留言吗？')) {
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/messages/${messageId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            showToast('留言删除成功', 'success');
            loadMessages(currentPage);
        } else {
            if (response.status === 401 || response.status === 403) {
                if (data.error === '只能删除自己的留言') {
                    showToast(data.error, 'error');
                } else {
                    handleTokenExpired();
                }
            } else {
                showToast(data.error || '删除留言失败', 'error');
            }
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('删除留言错误:', error);
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    currentPage = 1;
    
    showToast('已退出登录', 'info');
    showAuthSection();
    showLogin();
}

function handleTokenExpired() {
    showToast('登录已过期，请重新登录', 'error');
    logout();
}

function updateCharCount() {
    const count = messageContent.value.length;
    charCount.textContent = count;
    
    if (count > 500) {
        charCount.style.color = '#e53e3e';
    } else if (count > 400) {
        charCount.style.color = '#ed8936';
    } else {
        charCount.style.color = '#718096';
    }
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 24 * 60 * 60 * 1000 && date.getDate() === now.getDate()) {
        return date.toLocaleTimeString('zh-CN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }
    
    if (date.getFullYear() === now.getFullYear()) {
        return date.toLocaleDateString('zh-CN', { 
            month: 'numeric', 
            day: 'numeric',
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }
    
    return date.toLocaleDateString('zh-CN', { 
        year: 'numeric',
        month: 'numeric', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function showMainContent() {
    currentView = 'main';
    updateNavigation();
    
    document.getElementById('main-content').style.display = 'block';
    document.getElementById('profile-content').style.display = 'none';
    document.getElementById('my-messages-content').style.display = 'none';
    
    loadMessages(1);
}

function showProfile() {
    currentView = 'profile';
    
    document.getElementById('main-content').style.display = 'none';
    document.getElementById('my-messages-content').style.display = 'none';
    document.getElementById('profile-content').style.display = 'block';
    
    updateNavigation();
    
    // 强制重新加载个人信息，确保显示最新数据
    loadProfile();
}

function showMyMessages() {
    currentView = 'my-messages';
    updateNavigation();
    
    document.getElementById('main-content').style.display = 'none';
    document.getElementById('profile-content').style.display = 'none';
    document.getElementById('my-messages-content').style.display = 'block';
    
    loadMyMessages(1);
}

function updateNavigation() {
    const navBtns = document.querySelectorAll('.nav-btn');
    
    navBtns.forEach(btn => {
        btn.classList.remove('active');
        btn.style.background = '';
        btn.style.color = '';
        btn.style.boxShadow = '';
        btn.style.transform = '';
    });
    
    if (currentView === 'main') {
        navBtns[0].classList.add('active');
    } else if (currentView === 'profile') {
        navBtns[1].classList.add('active');
    } else if (currentView === 'my-messages') {
        navBtns[2].classList.add('active');
    }
}

async function loadProfile() {
    try {
        const token = localStorage.getItem('token');
        
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substring(7);
        const url = `${API_BASE}/user/profile?_t=${timestamp}&_r=${randomId}&_bust=${Math.random()}`;
        
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
                'Pragma': 'no-cache',
                'Expires': '-1',
                'If-None-Match': '*',
                'If-Modified-Since': 'Thu, 01 Jan 1970 00:00:00 GMT',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/plain, */*'
            }
        });

        if (response.ok || response.status === 304) {
            if (response.status === 304) {
                const forceResponse = await fetch(`${API_BASE}/user/profile?force=${Date.now()}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache'
                    }
                });
                
                if (forceResponse.ok) {
                    const data = await forceResponse.json();
                    userProfile = data.user;
                    renderProfile(userProfile);
                } else {
                    throw new Error(`强制请求失败: ${forceResponse.status}`);
                }
            } else {
                const data = await response.json();
                userProfile = data.user;
                renderProfile(userProfile);
            }
        } else if (response.status === 401) {
            handleTokenExpired();
        } else {
            const errorData = await response.json().catch(() => ({ error: '未知错误' }));
            console.error('Profile load error:', errorData);
            showToast('获取个人资料失败: ' + (errorData.error || '未知错误'), 'error');
        }
    } catch (error) {
        console.error('Network error details:', error);
        showToast('网络错误，请稍后重试: ' + error.message, 'error');
    }
}

function renderProfile(user) {
    document.getElementById('profile-username').textContent = user.username;
    document.getElementById('profile-email').value = user.email || '';
    document.getElementById('profile-bio').value = user.bio || '';
    document.getElementById('profile-location').value = user.location || '';
    document.getElementById('profile-website').value = user.website || '';
    document.getElementById('profile-created').textContent = formatDate(user.created_at);
    document.getElementById('profile-message-count').textContent = user.message_count || 0;
    
    updateAvatarDisplay(user.avatar_url);
}

function updateAvatarDisplay(avatarUrl) {
    const profileAvatar = document.getElementById('profile-avatar');
    const currentUserAvatar = document.getElementById('current-user-avatar');
    
    if (avatarUrl && avatarUrl.startsWith('data:image/')) {
        if (profileAvatar) {
            profileAvatar.style.backgroundImage = `url(${avatarUrl})`;
            profileAvatar.style.backgroundSize = 'cover';
            profileAvatar.style.backgroundPosition = 'center';
            profileAvatar.textContent = '';
        }
        if (currentUserAvatar) {
            currentUserAvatar.style.backgroundImage = `url(${avatarUrl})`;
            currentUserAvatar.style.backgroundSize = 'cover';
            currentUserAvatar.style.backgroundPosition = 'center';
            currentUserAvatar.textContent = '';
        }
    } else {
        if (profileAvatar) {
            profileAvatar.style.backgroundImage = '';
            profileAvatar.textContent = '👤';
        }
        if (currentUserAvatar) {
            currentUserAvatar.style.backgroundImage = '';
            currentUserAvatar.textContent = '👤';
        }
    }
}

async function updateAvatar(avatarUrl) {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/user/avatar`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ avatar_url: avatarUrl })
        });

        const data = await response.json();

        if (response.ok) {
            showToast('头像更新成功！', 'success');
            updateAvatarDisplay(avatarUrl);
            
            const updatedUser = { ...currentUser, avatar_url: avatarUrl };
            localStorage.setItem('user', JSON.stringify(updatedUser));
            currentUser = updatedUser;
        } else if (response.status === 401) {
            handleTokenExpired();
        } else {
            showToast(data.error || '头像更新失败', 'error');
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('头像更新错误:', error);
    }
}

async function updateProfile() {
    const email = document.getElementById('profile-email').value.trim();
    const bio = document.getElementById('profile-bio').value.trim();
    const location = document.getElementById('profile-location').value.trim();
    const website = document.getElementById('profile-website').value.trim();
    
    try {
        const token = localStorage.getItem('token');
        
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substring(7);
        
        const response = await fetch(`${API_BASE}/user/profile?_t=${timestamp}&_r=${randomId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            },
            body: JSON.stringify({ email, bio, location, website })
        });

        if (response.ok || response.status === 304) {
            showToast('个人信息更新成功！', 'success');
            
            setTimeout(() => {
                loadProfile();
            }, 500);
            
            if (response.ok && response.status !== 304) {
                try {
                    const data = await response.json();
                    
                    if (userProfile) {
                        userProfile.email = email;
                        userProfile.bio = bio;
                        userProfile.location = location;
                        userProfile.website = website;
                    }
                } catch (jsonError) {
                    
                }
            }
        } else if (response.status === 401) {
            handleTokenExpired();
        } else {
            const data = await response.json().catch(() => ({ error: '更新失败' }));
            showToast(data.error || '更新失败', 'error');
            console.error('Update profile error:', data);
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('更新个人信息网络错误:', error);
    }
}

async function loadMyMessages(page = 1) {
    try {
        const token = localStorage.getItem('token');
        
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substring(7);
        const url = `${API_BASE}/user/messages?page=${page}&limit=10&_t=${timestamp}&_r=${randomId}&_bust=${Math.random()}`;
        
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
                'Pragma': 'no-cache',
                'Expires': '-1',
                'If-None-Match': '*',
                'If-Modified-Since': 'Thu, 01 Jan 1970 00:00:00 GMT',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/plain, */*'
            }
        });

        if (response.ok || response.status === 304) {
            if (response.status === 304) {
                const forceResponse = await fetch(`${API_BASE}/user/messages?page=${page}&limit=10&force=${Date.now()}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache'
                    }
                });
                
                if (forceResponse.ok) {
                    const data = await forceResponse.json();
                    renderMyMessages(data.messages);
                    renderMyMessagesPagination(data.pagination);
                    
                    document.getElementById('my-messages-count').textContent = 
                        `共 ${data.pagination.total} 条留言`;
                } else {
                    throw new Error(`强制请求失败: ${forceResponse.status}`);
                }
            } else {
                const data = await response.json();
                renderMyMessages(data.messages);
                renderMyMessagesPagination(data.pagination);
                
                document.getElementById('my-messages-count').textContent = 
                    `共 ${data.pagination.total} 条留言`;
            }
        } else if (response.status === 401) {
            handleTokenExpired();
        } else {
            const errorData = await response.json().catch(() => ({ error: '未知错误' }));
            console.error('My messages load error:', errorData);
            showToast('获取个人留言失败: ' + (errorData.error || '未知错误'), 'error');
        }
    } catch (error) {
        console.error('Network error details:', error);
        showToast('网络错误，请稍后重试: ' + error.message, 'error');
    }
}

function renderMyMessages(messages) {
    const container = document.getElementById('my-messages-container');
    
    if (!messages || messages.length === 0) {
        container.innerHTML = `
            <div class="no-messages">
                <h3>📭 还没有留言</h3>
                <p>快去发布你的第一条留言吧！</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = messages.map(message => {
        const messageTime = formatDate(message.created_at);
        
        return `
            <div class="message-card" data-message-id="${message.id}">
                <div class="message-header">
                    <div class="message-user">
                        <div class="user-avatar" style="${message.user_avatar ? `background-image: url(${message.user_avatar}); background-size: cover; background-position: center;` : ''}">${message.user_avatar ? '' : '👤'}</div>
                        <span class="username">${escapeHtml(message.username)}</span>
                    </div>
                    <div class="message-meta">
                        <span class="message-time">${messageTime}</span>
                        <button class="btn-delete" onclick="deleteMyMessage(${message.id})" title="删除留言">🗑️</button>
                    </div>
                </div>
                <div class="message-content">
                    ${escapeHtml(message.content)}
                </div>
                <div class="message-actions">
                    <button class="action-btn like-btn" onclick="toggleLike(${message.id})" data-message-id="${message.id}">
                        <span class="like-icon">👍</span>
                        <span class="like-count">${message.like_count || 0}</span>
                    </button>
                    <button class="action-btn reply-btn" onclick="toggleReplyBox(${message.id})">
                        <span class="reply-icon">💬</span>
                        <span class="reply-count">${message.reply_count || 0}</span>
                    </button>
                    <button class="action-btn view-replies-btn" onclick="toggleReplies(${message.id})" style="display: ${(message.reply_count || 0) > 0 ? 'inline-flex' : 'none'}">
                        查看回复
                    </button>
                </div>
                <div class="reply-box" id="reply-box-${message.id}" style="display: none;">
                    <textarea placeholder="写下你的回复..." maxlength="300" class="reply-input" id="reply-input-${message.id}"></textarea>
                    <div class="reply-actions">
                        <span class="char-count-small"><span id="reply-char-count-${message.id}">0</span>/300</span>
                        <button class="btn btn-small" onclick="submitReply(${message.id})">发送回复</button>
                        <button class="btn btn-small btn-cancel" onclick="toggleReplyBox(${message.id})">取消</button>
                    </div>
                </div>
                <div class="replies-container" id="replies-${message.id}" style="display: none;">
                    <div class="replies-loading">加载回复中...</div>
                </div>
            </div>
        `;
    }).join('');

    updateLikeStatuses(messages);
}

function renderMyMessagesPagination(pagination) {
    const container = document.getElementById('my-messages-pagination');
    
    if (pagination.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    if (pagination.page > 1) {
        paginationHTML += `<button onclick="loadMyMessages(${pagination.page - 1})">上一页</button>`;
    }
    
    for (let i = 1; i <= pagination.totalPages; i++) {
        if (i === pagination.page) {
            paginationHTML += `<button class="active">${i}</button>`;
        } else {
            paginationHTML += `<button onclick="loadMyMessages(${i})">${i}</button>`;
        }
    }
    
    if (pagination.page < pagination.totalPages) {
        paginationHTML += `<button onclick="loadMyMessages(${pagination.page + 1})">下一页</button>`;
    }
    
    container.innerHTML = paginationHTML;
}

async function deleteMyMessage(messageId) {
    if (!confirm('确定要删除这条留言吗？')) {
        return;
    }
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE}/messages/${messageId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            showToast('留言删除成功！', 'success');
            loadMyMessages(1);
            
            if (currentView === 'main') {
                loadMessages(currentPage);
            }
        } else if (response.status === 401) {
            handleTokenExpired();
        } else {
            const data = await response.json();
            showToast(data.error || '删除失败', 'error');
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('删除留言错误:', error);
    }
}

function handleAvatarUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        showToast('请选择图片文件', 'error');
        return;
    }
    
    if (file.size > 2 * 1024 * 1024) {
        showToast('图片文件不能超过2MB', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            const canvas = document.getElementById('avatar-canvas');
            const ctx = canvas.getContext('2d');
            
            const maxSize = 100;
            let { width, height } = img;
            
            if (width > height) {
                if (width > maxSize) {
                    height = height * (maxSize / width);
                    width = maxSize;
                }
            } else {
                if (height > maxSize) {
                    width = width * (maxSize / height);
                    height = maxSize;
                }
            }
            
            canvas.width = width;
            canvas.height = height;
            
            ctx.drawImage(img, 0, 0, width, height);
            
            const dataURL = canvas.toDataURL('image/jpeg', 0.7);
            updateAvatar(dataURL);
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function showWelcomeModal() {
    const modal = document.getElementById('welcome-modal');
    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => {
            modal.style.opacity = '1';
        }, 10);
    }
}

function closeWelcomeModal() {
    const modal = document.getElementById('welcome-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

async function showUserProfile(userId) {
    if (!userId || userId === currentUser?.id) {
        showProfile();
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/users/${userId}/profile`);
        const data = await response.json();

        if (response.ok) {
            showUserProfileModal(data.user);
        } else {
            showToast(data.error || '获取用户资料失败', 'error');
        }
    } catch (error) {
        showToast('网络错误，请稍后重试', 'error');
        console.error('获取用户资料错误:', error);
    }
}

function showUserProfileModal(user) {
    const modal = document.createElement('div');
    modal.className = 'user-profile-modal';
    modal.innerHTML = `
        <div class="user-profile-content">
            <div class="user-profile-header">
                <button class="close-btn" onclick="closeUserProfileModal()">&times;</button>
                <div class="user-profile-avatar" style="${user.avatar_url ? `background-image: url(${user.avatar_url}); background-size: cover; background-position: center;` : ''}">${user.avatar_url ? '' : '👤'}</div>
                <h2>${escapeHtml(user.username)}</h2>
                ${user.bio ? `<p class="user-bio">${escapeHtml(user.bio)}</p>` : ''}
            </div>
            <div class="user-profile-details">
                ${user.location ? `
                    <div class="detail-item">
                        <span class="detail-icon">📍</span>
                        <span class="detail-text">${escapeHtml(user.location)}</span>
                    </div>
                ` : ''}
                ${user.website ? `
                    <div class="detail-item">
                        <span class="detail-icon">🌐</span>
                        <a href="${escapeHtml(user.website)}" target="_blank" class="detail-link">${escapeHtml(user.website)}</a>
                    </div>
                ` : ''}
                <div class="detail-item">
                    <span class="detail-icon">📅</span>
                    <span class="detail-text">加入于 ${formatDate(user.created_at)}</span>
                </div>
            </div>
            <div class="user-profile-stats">
                <div class="stat-item">
                    <span class="stat-number">${user.message_count || 0}</span>
                    <span class="stat-label">留言</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">${user.total_likes || 0}</span>
                    <span class="stat-label">获赞</span>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function closeUserProfileModal() {
    const modal = document.querySelector('.user-profile-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
} 