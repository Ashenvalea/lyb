const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const NODE_ENV = process.env.NODE_ENV || 'development';

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
    try {
        fs.mkdirSync(dataDir, { recursive: true });
        console.log('数据目录创建成功:', dataDir);
    } catch (error) {
        console.error('创建数据目录失败:', error);
    }
}

const DATA_FILE = path.join(dataDir, 'data.json');

let data = {
    users: [],
    messages: [],
    message_likes: [],
    message_replies: [],
    nextUserId: 1,
    nextMessageId: 1,
    nextLikeId: 1,
    nextReplyId: 1
};

const loadData = () => {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const fileData = fs.readFileSync(DATA_FILE, 'utf8');
            data = JSON.parse(fileData);
            console.log('数据加载成功');
        } else {
            saveData();
            console.log('创建新的数据文件');
        }
    } catch (error) {
        console.error('数据加载失败:', error);
        data = {
            users: [],
            messages: [],
            message_likes: [],
            message_replies: [],
            nextUserId: 1,
            nextMessageId: 1,
            nextLikeId: 1,
            nextReplyId: 1
        };
    }
};

const saveData = () => {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('数据保存失败:', error);
    }
};

loadData();

if (NODE_ENV === 'production') {
    app.set('trust proxy', 1);
    const allowedOrigins = process.env.ALLOWED_ORIGINS 
        ? process.env.ALLOWED_ORIGINS.split(',') 
        : ['http://182.92.159.55:3000', 'https://182.92.159.55:3000', 'http://localhost:3000'];
    
    app.use(cors({
        origin: function (origin, callback) {
            if (!origin || allowedOrigins.indexOf(origin) !== -1) {
                callback(null, true);
            } else {
                callback(new Error('Not allowed by CORS'));
            }
        },
        credentials: true
    }));
} else {
    app.use(cors());
}

app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static('public'));

if (NODE_ENV === 'production') {
    app.use((req, res, next) => {
        const timestamp = new Date().toISOString();
        console.log(`[${timestamp}] ${req.method} ${req.url} - ${req.ip}`);
        next();
    });
}

process.on('SIGINT', () => {
    console.log('\n正在关闭服务器...');
    saveData();
    process.exit(0);
});

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: '访问令牌缺失' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: '无效的访问令牌' });
    }
    req.user = user;
    next();
  });
};

const validateInput = (req, res, next) => {
    if (JSON.stringify(req.body).length > 10000) {
        return res.status(413).json({ error: '请求数据过大' });
    }
    next();
};

app.use('/api', validateInput);

app.use('/api', (req, res, next) => {
    res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
    });
    next();
});

app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: '用户名和密码不能为空' });
  }

  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: '输入格式错误' });
  }

  if (username.length < 3 || username.length > 20) {
    return res.status(400).json({ error: '用户名长度必须在3-20位之间' });
  }

  if (password.length < 6 || password.length > 50) {
    return res.status(400).json({ error: '密码长度必须在6-50位之间' });
  }
  
  if (!/^[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(username)) {
    return res.status(400).json({ error: '用户名只能包含字母、数字、下划线和中文' });
  }

  try {
    const existingUser = data.users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (existingUser) {
      return res.status(400).json({ 
        error: '该用户名已被注册，请更换其他用户名', 
        errorType: 'USER_EXISTS',
        existingUsername: username
      });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    
    const newUser = {
      id: data.nextUserId++,
      username,
      password: hashedPassword,
      email: null,
      avatar_url: null,
      bio: null,
      location: null,
      website: null,
      is_active: 1,
      last_login: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    data.users.push(newUser);
    saveData();
        
    const token = jwt.sign(
      { id: newUser.id, username }, 
      JWT_SECRET, 
      { expiresIn: '7d' } 
    );
    
    res.json({ 
      message: '注册成功', 
      token,
      user: { id: newUser.id, username }
    });
  } catch (error) {
    console.error('注册错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: '用户名和密码不能为空' });
  }

  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: '输入格式错误' });
  }

  const user = data.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  
  if (!user) {
    return res.status(400).json({ 
      error: '用户不存在，请先注册', 
      errorType: 'USER_NOT_FOUND',
      inputUsername: username
    });
  }

  bcrypt.compare(password, user.password, (err, isValidPassword) => {
    if (err) {
      console.error('登录错误:', err);
      return res.status(500).json({ error: '服务器错误' });
    }

    if (!isValidPassword) {
      return res.status(400).json({ 
        error: '密码错误，请重新输入正确密码', 
        errorType: 'INVALID_PASSWORD',
        username: user.username
      });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username }, 
      JWT_SECRET, 
      { expiresIn: '7d' }
    );

    res.json({ 
      message: '登录成功', 
      token,
      user: { id: user.id, username: user.username }
    });
  });
});

app.post('/api/messages', authenticateToken, (req, res) => {
  const { content } = req.body;

  if (!content || typeof content !== 'string' || content.trim().length === 0) {
    return res.status(400).json({ error: '留言内容不能为空' });
  }

  if (content.length > 500) {
    return res.status(400).json({ error: '留言内容不能超过500字符' });
  }

  const cleanContent = content.trim().replace(/\s+/g, ' ');

  const newMessage = {
    id: data.nextMessageId++,
    user_id: req.user.id,
    username: req.user.username,
    title: null,
    content: cleanContent,
    content_length: cleanContent.length,
    is_private: 0,
    like_count: 0,
    reply_count: 0,
    ip_address: null,
    user_agent: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  data.messages.push(newMessage);
  saveData();
  
  res.json({ 
    message: '留言发布成功',
    messageId: newMessage.id
  });
});

app.get('/api/messages', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(20, Math.max(1, parseInt(req.query.limit) || 10));
  const offset = (page - 1) * limit;

  const sortedMessages = data.messages.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const paginatedMessages = sortedMessages.slice(offset, offset + limit);

  const messagesWithCounts = paginatedMessages.map(message => {
    const likeCount = data.message_likes.filter(like => like.message_id === message.id).length;
    const replyCount = data.message_replies.filter(reply => reply.message_id === message.id).length;
    const user = data.users.find(u => u.id === message.user_id);
    
    return {
      ...message,
      like_count: likeCount,
      reply_count: replyCount,
      user_avatar: user ? user.avatar_url : null
    };
  });

  res.json({
    messages: messagesWithCounts,
    pagination: {
      page,
      limit,
      total: data.messages.length,
      totalPages: Math.ceil(data.messages.length / limit)
    }
  });
});

app.post('/api/messages/:id/like', authenticateToken, (req, res) => {
  const messageId = parseInt(req.params.id);

  if (!messageId || messageId <= 0) {
    return res.status(400).json({ error: '无效的留言ID' });
  }

  const message = data.messages.find(m => m.id === messageId);
  if (!message) {
    return res.status(404).json({ error: '留言不存在' });
  }

  const existingLike = data.message_likes.find(like => 
    like.message_id === messageId && like.user_id === req.user.id
  );

  if (existingLike) {
    data.message_likes = data.message_likes.filter(like => like.id !== existingLike.id);
    saveData();
    res.json({ message: '取消点赞成功', liked: false });
  } else {
    const newLike = {
      id: data.nextLikeId++,
      message_id: messageId,
      user_id: req.user.id,
      created_at: new Date().toISOString()
    };
    data.message_likes.push(newLike);
    saveData();
    res.json({ message: '点赞成功', liked: true });
  }
});

app.get('/api/messages/:id/like-status', authenticateToken, (req, res) => {
  const messageId = parseInt(req.params.id);

  if (!messageId || messageId <= 0) {
    return res.status(400).json({ error: '无效的留言ID' });
  }

  const liked = data.message_likes.some(like => 
    like.message_id === messageId && like.user_id === req.user.id
  );

  res.json({ liked });
});

app.post('/api/messages/:id/reply', authenticateToken, (req, res) => {
  const messageId = parseInt(req.params.id);
  const { content } = req.body;

  if (!messageId || messageId <= 0) {
    return res.status(400).json({ error: '无效的留言ID' });
  }

  if (!content || typeof content !== 'string' || content.trim().length === 0) {
    return res.status(400).json({ error: '回复内容不能为空' });
  }

  if (content.length > 300) {
    return res.status(400).json({ error: '回复内容不能超过300字符' });
  }

  const message = data.messages.find(m => m.id === messageId);
  if (!message) {
    return res.status(404).json({ error: '留言不存在' });
  }

  const cleanContent = content.trim().replace(/\s+/g, ' ');

  const newReply = {
    id: data.nextReplyId++,
    message_id: messageId,
    user_id: req.user.id,
    username: req.user.username,
    content: cleanContent,
    created_at: new Date().toISOString()
  };

  data.message_replies.push(newReply);
  saveData();

  res.json({ 
    message: '回复成功',
    replyId: newReply.id
  });
});

app.get('/api/messages/:id/replies', (req, res) => {
  const messageId = parseInt(req.params.id);
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(10, Math.max(1, parseInt(req.query.limit) || 5));
  const offset = (page - 1) * limit;

  if (!messageId || messageId <= 0) {
    return res.status(400).json({ error: '无效的留言ID' });
  }

  const messageReplies = data.message_replies.filter(reply => reply.message_id === messageId);
  const sortedReplies = messageReplies.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const paginatedReplies = sortedReplies.slice(offset, offset + limit);

  const repliesWithUserInfo = paginatedReplies.map(reply => {
    const user = data.users.find(u => u.id === reply.user_id);
    return {
      ...reply,
      user_avatar: user ? user.avatar_url : null
    };
  });

  res.json({
    replies: repliesWithUserInfo,
    pagination: {
      page,
      limit,
      total: messageReplies.length,
      totalPages: Math.ceil(messageReplies.length / limit)
    }
  });
});

app.delete('/api/replies/:id', authenticateToken, (req, res) => {
  const replyId = parseInt(req.params.id);

  if (!replyId || replyId <= 0) {
    return res.status(400).json({ error: '无效的回复ID' });
  }

  const reply = data.message_replies.find(r => r.id === replyId);
  
  if (!reply) {
    return res.status(404).json({ error: '回复不存在' });
  }

  if (reply.user_id !== req.user.id) {
    return res.status(403).json({ error: '只能删除自己的回复' });
  }

  data.message_replies = data.message_replies.filter(r => r.id !== replyId);
  saveData();

  res.json({ message: '回复删除成功' });
});

app.delete('/api/messages/:id', authenticateToken, (req, res) => {
  const messageId = parseInt(req.params.id);

  if (!messageId || messageId <= 0) {
    return res.status(400).json({ error: '无效的留言ID' });
  }

  const message = data.messages.find(m => m.id === messageId);
  
  if (!message) {
    return res.status(404).json({ error: '留言不存在' });
  }

  if (message.user_id !== req.user.id) {
    return res.status(403).json({ error: '只能删除自己的留言' });
  }

  data.messages = data.messages.filter(m => m.id !== messageId);
  data.message_replies = data.message_replies.filter(r => r.message_id !== messageId);
  data.message_likes = data.message_likes.filter(l => l.message_id !== messageId);
  saveData();

  res.json({ message: '留言删除成功' });
});

app.get('/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        environment: NODE_ENV 
    });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/user/profile', authenticateToken, (req, res) => {
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });
  
  const user = data.users.find(u => u.id === req.user.id);
  
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }

  const messageCount = data.messages.filter(m => m.user_id === req.user.id).length;
  
  res.json({
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      avatar_url: user.avatar_url,
      bio: user.bio,
      location: user.location,
      website: user.website,
      created_at: user.created_at,
      last_login: user.last_login,
      message_count: messageCount
    }
  });
});

app.put('/api/user/avatar', authenticateToken, (req, res) => {
  const { avatar_url } = req.body;
  
  if (!avatar_url || typeof avatar_url !== 'string') {
    return res.status(400).json({ error: '头像数据无效' });
  }
  
  if (!avatar_url.startsWith('data:image/')) {
    return res.status(400).json({ error: '只支持图片格式的头像' });
  }
  
  const user = data.users.find(u => u.id === req.user.id);
  
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }

  user.avatar_url = avatar_url;
  saveData();
  
  res.json({ 
    message: '头像更新成功',
    avatar_url 
  });
});

app.get('/api/user/messages', authenticateToken, (req, res) => {
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });
  
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(20, Math.max(1, parseInt(req.query.limit) || 10));
  const offset = (page - 1) * limit;
  
  const userMessages = data.messages.filter(m => m.user_id === req.user.id);
  const sortedMessages = userMessages.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const paginatedMessages = sortedMessages.slice(offset, offset + limit);

  const messagesWithCounts = paginatedMessages.map(message => {
    const likeCount = data.message_likes.filter(like => like.message_id === message.id).length;
    const replyCount = data.message_replies.filter(reply => reply.message_id === message.id).length;
    const user = data.users.find(u => u.id === message.user_id);
    
    return {
      ...message,
      like_count: likeCount,
      reply_count: replyCount,
      user_avatar: user ? user.avatar_url : null
    };
  });
  
  res.json({
    messages: messagesWithCounts,
    pagination: {
      page,
      limit,
      total: userMessages.length,
      totalPages: Math.ceil(userMessages.length / limit)
    }
  });
});

app.put('/api/user/profile', authenticateToken, (req, res) => {
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
    'ETag': false,
    'Last-Modified': false
  });
  
  const { email, bio, location, website } = req.body;
  
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: '邮箱格式无效' });
  }

  if (bio && bio.length > 200) {
    return res.status(400).json({ error: '个人简介不能超过200字符' });
  }

  if (location && location.length > 50) {
    return res.status(400).json({ error: '所在地不能超过50字符' });
  }

  if (website && website.length > 100) {
    return res.status(400).json({ error: '个人网站不能超过100字符' });
  }
  
  const user = data.users.find(u => u.id === req.user.id);
  
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }

  if (email !== undefined) {
    user.email = email;
  }
  if (bio !== undefined) {
    user.bio = bio;
  }
  if (location !== undefined) {
    user.location = location;
  }
  if (website !== undefined) {
    user.website = website;
  }

  user.updated_at = new Date().toISOString();

  saveData();
  res.json({ 
    message: '个人信息更新成功',
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      bio: user.bio,
      location: user.location,
      website: user.website,
      updated_at: user.updated_at
    }
  });
});

app.get('/api/users/:id/profile', (req, res) => {
  const userId = parseInt(req.params.id);

  if (!userId || userId <= 0) {
    return res.status(400).json({ error: '无效的用户ID' });
  }

  const user = data.users.find(u => u.id === userId);
  
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }

  const messageCount = data.messages.filter(m => m.user_id === userId).length;
  const likeCount = data.message_likes.filter(like => {
    const message = data.messages.find(m => m.id === like.message_id);
    return message && message.user_id === userId;
  }).length;
  
  res.json({
    user: {
      id: user.id,
      username: user.username,
      avatar_url: user.avatar_url,
      bio: user.bio,
      location: user.location,
      website: user.website,
      created_at: user.created_at,
      message_count: messageCount,
      total_likes: likeCount
    }
  });
});

app.use('*', (req, res) => {
    res.status(404).json({ error: '页面不存在' });
});

app.use((err, req, res, next) => {
    console.error('服务器错误:', err);
    res.status(500).json({ error: '服务器内部错误' });
});

app.listen(PORT, () => {
  console.log(`留言板服务器运行在端口 ${PORT}`);
  console.log(`环境: ${NODE_ENV}`);
  console.log(`数据文件: ${DATA_FILE}`);
}); 